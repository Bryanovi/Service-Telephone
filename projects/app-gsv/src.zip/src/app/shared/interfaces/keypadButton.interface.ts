export interface KeypadButton {
  icon: string;
  color: string;
  accion: string;
}
