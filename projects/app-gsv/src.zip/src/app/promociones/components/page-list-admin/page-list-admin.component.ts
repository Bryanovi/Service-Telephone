import { Component } from '@angular/core';

@Component({
  selector: 'gsv-page-list-admin',
  templateUrl: './page-list-admin.component.html',
  styleUrls: ['./page-list-admin.component.css']
})
export class PageListAdminComponent {

}
