import { Component } from '@angular/core';
import { MetaDataColumn } from '../../../shared/interfaces/metadatacolumn.interface';

@Component({
  selector: 'gsv-page-list-client',
  templateUrl: './page-list-client.component.html',
  styleUrls: ['./page-list-client.component.css'],
})
export class PageListClientComponent {
  registros: any[] = [];
  metaDataColumns: MetaDataColumn[] = [
    // { field: '_id', title: 'ID' },
    { field: 'id', title: 'ID' },
    { field: 'producto', title: 'PRODUCTO' },
    { field: 'descuento', title: 'DESCUENTO' },
    { field: 'fechaInicio', title: 'FECHA INICIO' },
    { field: 'fechaFin', title: 'FECHA FIN' },
  ];

  data: any[] = [];
  totalRegistros = this.data.length;

  constructor(private cajaService: CajaService) {
    this.cargarRegistroCaja();
  }

  cargarRegistroCaja() {
    this.cajaService.cargarCajas().subscribe((dataWeb) => {
      this.registros = dataWeb;
      this.totalRegistros = this.registros.length;
      this.changePage(0);
    });
  }

  changePage(page: number) {
    const pageSize = environment.PAGE_SIZE;
    const salto = pageSize * page;
    this.data = this.registros.slice(salto, salto + pageSize);
  }
}
