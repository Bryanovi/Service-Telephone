export const environment = {
  production: false,
  PAGE_SIZE: 2,
  firebaseConfig: {
    apiKey: 'AIzaSyC_IumrNjqAxWPSGq_-_6EQTpvIaM3Qtq8',
    authDomain: 'crudview-d9469.firebaseapp.com',
    databaseURL: 'https://crudview-d9469-default-rtdb.firebaseio.com',
    projectId: 'crudview-d9469',
    storageBucket: 'crudview-d9469.appspot.com',
    messagingSenderId: '3245605787',
    appId: '1:3245605787:web:ffe4888ddb9cc35dedd73e',
  },
};
