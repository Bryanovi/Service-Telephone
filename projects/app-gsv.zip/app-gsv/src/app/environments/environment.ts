export const environment = {
  production: false,
  PAGE_SIZE: 2,
  firebaseConfig: {
    apiKey: "AIzaSyCSfmb3eQ09u_baLxfRdB_vHesXa9ElhKc",
  authDomain: "webtelefonia-49078.firebaseapp.com",
  projectId: "webtelefonia-49078",
  storageBucket: "webtelefonia-49078.appspot.com",
  messagingSenderId: "91567318781",
  appId: "1:91567318781:web:54026f8ac17c5d23db4094",
  measurementId: "G-15Y2Q3C66Z"
  },
};
