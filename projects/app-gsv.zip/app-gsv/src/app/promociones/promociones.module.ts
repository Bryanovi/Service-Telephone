import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PromocionesRoutingModule } from './promociones-routing.module';
import { PageListComponent } from './pages/page-list/page-list.component';
import { FormComponent } from './components/form/form.component';
import { PromocionTableComponent } from './components/promocion-table/promocion-table.component';
import { PageListClientComponent } from './components/page-list-client/page-list-client.component';
import { PageListAdminComponent } from './components/page-list-admin/page-list-admin.component';


@NgModule({
  declarations: [
    PageListComponent,
    FormComponent,
    PromocionTableComponent,
    PageListClientComponent,
    PageListAdminComponent
  ],
  imports: [
    CommonModule,
    PromocionesRoutingModule
  ],
  exports: [
    PromocionTableComponent,
    PageListClientComponent,
    PageListAdminComponent
  ]
})
export class PromocionesModule { }
